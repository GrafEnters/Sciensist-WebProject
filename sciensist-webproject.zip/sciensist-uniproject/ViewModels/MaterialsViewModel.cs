﻿using EggHuntersSocialNetwork.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EggHuntersSocialNetwork.ViewModels
{
	public class MaterialsViewModel
	{
		public IEnumerable<Material> Materials { get; set; }
		public Material toAdd { get; set; }
		public Material editMaterial { get; set; }
		public int editId { get; set; }
		public int deleteId { get; set; }

	}
}
