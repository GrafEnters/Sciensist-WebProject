﻿using EggHuntersSocialNetwork.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EggHuntersSocialNetwork.ViewModels
{
	public class PlayersViewModel
	{
		public IEnumerable<Player> Users { get; set; }
		public Player editUser { get; set; }
	}
}
