﻿using EggHuntersSocialNetwork.Data.Models;
using EggHuntersSocialNetwork.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EggHuntersSocialNetwork.ViewModels
{
	public class GameViewModel
	{
		public Question question { get; set; }

		public string userName { get; set; }

		[Display(Name = "Введите ответ")]
		[StringLength(500)]
		[Required(ErrorMessage = "Ответ не может быть пустым")]
		public string answer { get; set; }
	}
}
