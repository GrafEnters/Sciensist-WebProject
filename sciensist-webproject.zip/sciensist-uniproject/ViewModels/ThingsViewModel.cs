﻿using EggHuntersSocialNetwork.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EggHuntersSocialNetwork.ViewModels
{
	public class ThingsViewModel
	{
		public IEnumerable<Thing> Things { get; set; }
		public IEnumerable<Material> Materials { get; set; }
		public Thing toAdd { get; set; }
		public Thing editThing { get; set; }
		public int  editId { get; set; }
		public int  deleteId { get; set; }

	}
}
