﻿using EggHuntersSocialNetwork.Data.Models;
using EggHuntersSocialNetwork.Utils;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EggHuntersSocialNetwork.ViewModels
{
	public class NewsViewModel
	{
		public string[] Headers { get; set; }
		public string[] imgs { get; set; }
		public string[] links { get; set; }
	}
}
