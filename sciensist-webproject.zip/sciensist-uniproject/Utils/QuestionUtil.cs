﻿using EggHuntersSocialNetwork.Data.Interfaces;
using EggHuntersSocialNetwork.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EggHuntersSocialNetwork.Utils
{
	public static class QuestionUtil
	{

		public static Question GenerateQuestion(IThings things, IMaterials materials)
		{
			switch (new Random().Next() % 3)	 
			{
				case 0:
					Thing thing1 = things.GetRandom();
					Thing thing2 = things.GetRandom();
					int weight1 = thing1.volume * materials.GetMaterialById(thing1.materialId).durabiliy;
					int weight2 = thing2.volume * materials.GetMaterialById(thing2.materialId).durabiliy;
					int rndNOK = nok(weight1, weight2) * (new Random().Next() % 5 + 1);

					return new Question(
						"Жена отправила меня на ярмарку в город Н. Строго настрого запретила возвращаться без мешка " + thing1.name.ToUpper() + ", весом как " + (rndNOK / weight2).ToString() + " " + thing2.name.ToUpper() + "." +
						" Вот только я человек простой, на глаз взвешивать не умею. Помоги замужнему, сколько  " + thing1.name.ToUpper() + " мне купить?",
						rndNOK / weight1);

				case 1:

					Material[] matsDensSorted = materials.Materials.OrderBy(s => s.density).ToArray();
					int count = matsDensSorted.Count();

					int ideal = new Random().Next() % (count - 4) + 2;
					Material light = matsDensSorted[ideal - (new Random().Next() % 2 + 1)];
					Material heavy = matsDensSorted[ideal + (new Random().Next() % 2 + 1)];

					return new Question(
						 "Моя дочь очень больна. Шаманы нашей деревни предрекли ей верную смерть. Но я не сдаюсь. На диких островах посреди азурного моря растут удивительные травы, " +
						 "способные излечить даже мертвеца. Помоги мне построить корабль, а взамен я щедро отплачу тебе ОДНИМ ПРАВИЛЬНЫМ ОТВЕТОМ в статистике. " +
						 "Бывалые моряки из нашей деревни пытались добраться до островов на кораблях из " + heavy.name.ToUpper() + ", но потонули у самого берега. " +
						 "Один корабль из " + light.name.ToUpper() + " сдуло сильным ветром на скалы. Теперь отплываю я сам, больше смертей я допустить не могу. " +
						 "Так из какой ВЕЩИ мне сделать корабль?",
				light.density,
				heavy.density,
				Question.VariableType.density);
				case 2:

					Material[] matsDurSorted = materials.Materials.OrderBy(s => s.durabiliy).ToArray();
					count = matsDurSorted.Count();

					ideal = new Random().Next() % (count - 4) + 2;
					Material weak = matsDurSorted[ideal - (new Random().Next() % 2 + 1)];
					Material strong = matsDurSorted[ideal + (new Random().Next() % 2 + 1)];


					return new Question(
						  "Я очень люблю своего брата. Подшиваю ему ботинки, готовлю, расспрашиваю как дела в шахте. " +
						  "И каждый раз он отвечает, что его кирка из " + weak.name.ToUpper() + " уже совсем старая и не ломает волшебную руду. " +
						  "Кирку можно сделать из любой ВЕЩИ, главное чтобы он не СГОРЕЛА в печи. Я много раз предлагала попросить кузнеца сделать новую, но брат отказывался. " +
						  "Оказалось недавно на их выработке появился новый старатель, и его кайло из " + strong.name.ToUpper() + " за один удар превратило целую жилу в пыль. Его тут же повесили! " +
						  "Мне очень страшно, но так дело оставлять нельзя. Что же мне принести кузнецу на переплавку?",
				weak.durabiliy,
				strong.durabiliy,
				Question.VariableType.durability,
				Question.PamType.Flame0);

				default:
					return new Question(
						"",
						"");
			}
		}

		static int nod(int a, int b)
		{
			while (b > 0)
			{
				int temp = b;
				b = a % b;
				a = temp;
			}
			return a;
		}
		static int nok(int a, int b)
		{
			return Math.Abs(a * b) / nod(a, b);
		}

	}
}
