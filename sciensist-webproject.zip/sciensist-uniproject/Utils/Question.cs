﻿using EggHuntersSocialNetwork.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EggHuntersSocialNetwork.Utils
{
	public class Question
	{

		public string sentense;
		public string answer;
		public QuestionType Qtype;
		public VariableType Vtype;
		public PamType Ptype;
		public int min, max, exact;


		public Question(string sentense)
		{
			this.sentense = sentense;
		}


		public Question(string sentence, string answer)
		{
			this.sentense = sentence;
			this.answer = answer;
		}

		public Question(string sentence, int min, int max,VariableType Vtype)
		{
			Qtype = QuestionType.BetwMinMax;
			this.sentense = sentence;
			this.min = min;
			this.max = max;
			this.Vtype = Vtype;
		}

		public Question(string sentence, int min, int max, VariableType Vtype,PamType Ptype)
		{
			Qtype = QuestionType.BetwWithPam;
			this.sentense = sentence;
			this.min = min;
			this.max = max;
			this.Vtype = Vtype;
			this.Ptype = Ptype;

		}


		public Question(string sentence, int exact)
		{
			Qtype = QuestionType.OneNumber;
			Vtype = VariableType.number;
			this.sentense = sentence;
			this.exact = exact;
		}


		public bool IsCorrect(string ans, IThings things, IMaterials materials)
		{
			switch (Qtype)
			{
				case QuestionType.BetwMinMax:
					switch (Vtype)
					{
						case VariableType.density:
							return (materials.GetMaterialById(things.GetThingByName(ans).materialId).density > min && materials.GetMaterialById(things.GetThingByName(ans).materialId).density < max);
							
					}
					break;
				case QuestionType.BetwWithPam:
					switch (Ptype)
					{
						case PamType.Conduct0:
							if(materials.GetMaterialById(things.GetThingByName(ans).materialId).isConducting)
								return false;
							break;
						case PamType.Flame0:
							if (materials.GetMaterialById(things.GetThingByName(ans).materialId).isFlammable)
								return false;
							break;
					}

					switch (Vtype)
					{
						case VariableType.density:
							return (materials.GetMaterialById(things.GetThingByName(ans).materialId).density > min && materials.GetMaterialById(things.GetThingByName(ans).materialId).density < max);
						case VariableType.durability:
							return (materials.GetMaterialById(things.GetThingByName(ans).materialId).durabiliy > min && materials.GetMaterialById(things.GetThingByName(ans).materialId).durabiliy < max);

					}
					break;
				case QuestionType.OneNumber:
					return int.Parse(ans) == exact;

			}
			return false;
		}

		public enum QuestionType
		{
			OneNumber,
			BetwMinMax,
			BetwWithPam
			
		}
		public enum VariableType
		{
			number,
			volume,
			density,
			durability
		}
		public enum PamType
		{
			Conduct0,
			Conduct1,
			Flame0,
			Flame1
		}
	}
}
