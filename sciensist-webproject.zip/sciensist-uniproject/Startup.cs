﻿using EggHuntersSocialNetwork.Data;
using EggHuntersSocialNetwork.Data.Interfaces;
using EggHuntersSocialNetwork.Data.Models;
using EggHuntersSocialNetwork.Data.Repository;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace EggHuntersSocialNetwork
{
	public class Startup
	{
		private IConfigurationRoot _confString;

		public Startup(IHostingEnvironment hostInv)
		{
			_confString = new ConfigurationBuilder().SetBasePath(hostInv.ContentRootPath).AddJsonFile("DBsettings.json").Build();
		}

		public void ConfigureServices(IServiceCollection services)
		{
			services.AddDbContext<AppDBcontent>(options => options.UseSqlServer(_confString.GetConnectionString("DefaultConnection")));

			services.AddTransient<IThings, ThingRepository>();
			services.AddTransient<IPlayers, UserRepository>();
			services.AddTransient<IMaterials, MaterialRepository>();

			services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
			services.AddScoped(sp => Game.GetGame(sp));


			services.AddMvc();
			services.AddMemoryCache();
			services.AddSession();

		}

		public void Configure(IApplicationBuilder app, IHostingEnvironment env)
		{
			app.UseDeveloperExceptionPage();
			app.UseStatusCodePages();
			app.UseStaticFiles();
			app.UseSession();


			//Настройка путей
			app.UseMvc(routes =>
			{
				routes.MapRoute(name: "default", template: "{controller=Home}/{action=Index}/{id?}");
				routes.MapRoute(name: "email", template: "Admin/{action}/{email?}", defaults: new { Controller = "Admin", action = "Index" });

			});

			//Создание гостевого пользователя
			DBObjects.curUser = new Player();
			DBObjects.guestName = "Незнакомец";
			DBObjects.curUser.name = "Незнакомец";

		}
	}
}
