﻿using EggHuntersSocialNetwork.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace EggHuntersSocialNetwork.Data
{
	public class AppDBcontent : DbContext
	{
		public DbSet<Player> Players { get; set; }
		public DbSet<Material> Materials { get; set; }
		public DbSet<Thing> Things { get; set; }

		public AppDBcontent(DbContextOptions<AppDBcontent> options) : base(options)
		{
			Database.EnsureCreated();
		
		}
	}
}
