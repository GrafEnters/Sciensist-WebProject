﻿using EggHuntersSocialNetwork.Data.Interfaces;
using EggHuntersSocialNetwork.Data.Models;
using System.Collections.Generic;
using System.Linq;

namespace EggHuntersSocialNetwork.Data.Repository
{
	public class UserRepository : IPlayers
	{
		// Тут будут добавлятся и сохраняться элементы в ДБ
		private readonly AppDBcontent appDBContent;
		public UserRepository(AppDBcontent appDBContent)
		{
			this.appDBContent = appDBContent;
		}

		public void CreatePlayer(Player newUser)
		{
			if (newUser.email == "graf.enters@gmail.com")
			{
				newUser.isAdmin = true; newUser.isManager = true;
			}
			appDBContent.Players.Add(newUser);
			appDBContent.SaveChanges();
		}

		public void EditPlayer(Player toChange)
		{
			var player = appDBContent.Players

	   .Where(c => c.email == toChange.email)
	   .FirstOrDefault();

			// Внести изменения
			player.name = toChange.name;
			player.isManager = toChange.isManager;
			player.isAdmin = toChange.isAdmin;
			player.correctAns = toChange.correctAns;
			player.wrongAns = toChange.wrongAns;

			appDBContent.SaveChanges();
		}

		public IEnumerable<Player> Players => appDBContent.Players;

		public bool IsPlayerExistByEmail(string email) => appDBContent.Players.FirstOrDefault(p => p.email == email) != null;

		public Player GetPlayerByEmail(string email) => appDBContent.Players.FirstOrDefault(p => p.email == email);

		public Player GetPlayerById(int id) => appDBContent.Players.FirstOrDefault(u => u.id == id);

		public void DeletePlayer(int id)
		{
			var player = Players.FirstOrDefault(u => u.id == id);
			if (player != null)
				appDBContent.Players.Remove(player);
			appDBContent.SaveChanges();
		}
	}
}
