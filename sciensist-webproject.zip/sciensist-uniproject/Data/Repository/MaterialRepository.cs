﻿using EggHuntersSocialNetwork.Data.Interfaces;
using EggHuntersSocialNetwork.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EggHuntersSocialNetwork.Data.Repository
{
	public class MaterialRepository : IMaterials
	{
		private readonly AppDBcontent appDBContent;
		public MaterialRepository(AppDBcontent appDBContent)
		{
			this.appDBContent = appDBContent;
		}

		public IEnumerable<Material> Materials => appDBContent.Materials;



		public void CreateMaterial(Material newMaterial)
		{
			appDBContent.Materials.Add(newMaterial);
			appDBContent.SaveChanges();
		}

		public Material GetMaterialById(int id) => appDBContent.Materials.FirstOrDefault(t => t.id == id);


		public void EditMaterial(Material toChange)
		{
			var material = appDBContent.Materials
	   // Загрузить покупателя с фамилией "Иванов"
	   .Where(c => c.id == toChange.id)
	   .FirstOrDefault();

			// Внести изменения
			material.name = toChange.name;
			material.density = toChange.density;
			material.durabiliy = toChange.durabiliy;
			material.isFlammable = toChange.isFlammable;
			material.isConducting = toChange.isConducting;

			appDBContent.SaveChanges();
		}

		public void DeleteMaterial(int id)
		{
			var material = Materials.FirstOrDefault(u => u.id == id);
			if (material != null)
				appDBContent.Materials.Remove(material);
			appDBContent.SaveChanges();
		}


		public Material GetRandom() => appDBContent.Materials.Skip(new Random().Next(0, Materials.Count())).FirstOrDefault();


	}
}
