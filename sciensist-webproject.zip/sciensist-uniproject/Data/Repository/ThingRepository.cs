﻿using EggHuntersSocialNetwork.Data.Interfaces;
using EggHuntersSocialNetwork.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EggHuntersSocialNetwork.Data.Repository
{
	public class ThingRepository : IThings
	{
		private readonly AppDBcontent appDBContent;
		public ThingRepository(AppDBcontent appDBContent)
		{
			this.appDBContent = appDBContent;
		}

		public IEnumerable<Thing> Things => appDBContent.Things;

		public void CreateThing(Thing newThing)
		{
			appDBContent.Things.Add(newThing);
			appDBContent.SaveChanges();
		}

		public void EditThing(Thing toChange)
		{
			var thing = appDBContent.Things
	   // Загрузить покупателя с фамилией "Иванов"
	   .Where(c => c.id == toChange.id)
	   .FirstOrDefault();

			// Внести изменения
			thing.name = toChange.name;
			thing.volume = toChange.volume;

			appDBContent.SaveChanges();
		}

		public void DeleteThing(int id)
		{
			var thing = Things.FirstOrDefault(u => u.id == id);
			if (thing != null)
				appDBContent.Things.Remove(thing);
			appDBContent.SaveChanges();
		}

		public Thing GetThingById(int id) => appDBContent.Things.FirstOrDefault(t => t.id == id);

		public Thing GetThingByName(string name) => appDBContent.Things.FirstOrDefault(t => t.name == name);

		public bool IsThingExist(string name) => appDBContent.Things.FirstOrDefault(t => t.name == name) != null;

		public Thing GetRandom() => appDBContent.Things.Skip(new Random().Next(0, Things.Count())).FirstOrDefault();

	}
}
