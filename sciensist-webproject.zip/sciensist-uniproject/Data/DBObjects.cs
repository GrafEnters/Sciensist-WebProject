﻿using EggHuntersSocialNetwork.Data.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EggHuntersSocialNetwork.Data
{
	public class DBObjects
	{
		public static void Initial(AppDBcontent content)
		{		
			content.SaveChanges();
		}

		public static Player curUser;
		public static string guestName = "Незнакомец";
		public static Player editUser;
		public static int deleteThingId;

	}

}

