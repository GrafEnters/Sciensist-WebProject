﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EggHuntersSocialNetwork.Data.Models
{
	public class Player : Guest
	{
		[Display(Name = "Введите имя")]
		[StringLength(40)]
		[Required(ErrorMessage = "Длина имени не более 40 символов")]
		public string name { get; set; }

		public bool isManager { get; set; }

		public bool isAdmin { get; set; }
		public int correctAns { get; set; }
		public int wrongAns { get; set; }


		public Player()
		{
		}

		public Player(Player old)
		{
			this.email = old.email;
			this.password = old.password;
			this.name = old.name;
			this.isManager = old.isManager;
			this.isAdmin = old.isAdmin;
			this.correctAns = old.correctAns;
			this.wrongAns = old.wrongAns;
		}
	}
}
