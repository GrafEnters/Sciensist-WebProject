﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EggHuntersSocialNetwork.Data.Models
{
	public class Material
	{
		public int id { get; set; }
		public string name { get; set; }
		public int durabiliy { get; set; }
		public int density { get; set; }
		public bool isFlammable { get; set; }
		public bool isConducting { get; set; }
		

		public Material()
		{

		}

		public Material(bool isNew)
		{

			this.name = "";
			this.density = 0;
			this.durabiliy = 0;
			this.isFlammable = false;
			this.isConducting = false;
		}

		public Material(Material old)
		{
			this.id = old.id;
			this.name = old.name;
			this.density = old.density;
			this.durabiliy = old.durabiliy;
			this.isFlammable = old.isFlammable;
			this.isConducting = old.isConducting;
		}



	}
}
