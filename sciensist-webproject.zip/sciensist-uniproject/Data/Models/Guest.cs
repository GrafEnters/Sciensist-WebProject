﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EggHuntersSocialNetwork.Data.Models
{
	public class Guest
	{
		[BindNever]
		public int id { get; set; }

		[Display(Name = "Введите email")]
		[DataType(DataType.EmailAddress)]
		[Required(ErrorMessage = "Email не корректный")]
		public string email { get; set; }

		[Display(Name = "Введите пароль")]
		[DataType(DataType.Password)]
		[Required(ErrorMessage = "Пароль не подходит")]
		public string password { get; set; }

	}
}
