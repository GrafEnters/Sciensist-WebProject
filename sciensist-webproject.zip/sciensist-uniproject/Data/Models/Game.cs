﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EggHuntersSocialNetwork.Data.Models
{
	public class Game
	{
		public string GameId { get; set; }
		public virtual Player user { set; get; }


		private readonly AppDBcontent appDBcontent;

		public Game(AppDBcontent appDBcontent)
		{
			this.appDBcontent = appDBcontent;
		}

		public static Game GetGame(IServiceProvider services)
		{
			ISession session = services.GetRequiredService<IHttpContextAccessor>()?.HttpContext.Session;
			var context = services.GetService<AppDBcontent>();
			string gameId = session.GetString("GameId") ?? Guid.NewGuid().ToString();

			session.SetString("GameId", gameId);

			return new Game(context) { GameId = gameId };
		}
	}
}
