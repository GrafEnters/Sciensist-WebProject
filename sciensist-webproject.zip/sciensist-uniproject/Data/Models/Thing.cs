﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EggHuntersSocialNetwork.Data.Models
{
	public class Thing
	{
		public int id { get; set; }
		public string name { set; get; }
		public int volume { get; set; }
		public int materialId { get; set; }

		public Thing()
		{

		}

		public Thing( bool isNew)
		{

			this.name = "";
			this.volume = 0;
			this.materialId = 1;
		}

		public Thing(Thing old)
		{
			this.id = old.id;
			this.name = old.name;
			this.volume = old.volume;
			this.materialId = 1;
		}

	}
}
