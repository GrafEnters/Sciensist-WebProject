﻿using EggHuntersSocialNetwork.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EggHuntersSocialNetwork.Data.Interfaces
{
	public interface IMaterials
	{

		void CreateMaterial(Material newThing);


		void EditMaterial(Material user);

		IEnumerable<Material> Materials { get; }

		Material GetRandom();
		Material GetMaterialById(int id);

		void DeleteMaterial(int id);

	}
}
