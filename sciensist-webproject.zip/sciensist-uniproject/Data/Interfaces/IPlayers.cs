﻿using EggHuntersSocialNetwork.Data.Models;
using System.Collections.Generic;

namespace EggHuntersSocialNetwork.Data.Interfaces
{
	public interface IPlayers
	{
		void CreatePlayer(Player user);
		void EditPlayer(Player user);
		void DeletePlayer(int id);
		IEnumerable<Player> Players { get; }

		Player GetPlayerById(int id);
		Player GetPlayerByEmail(string email);
		bool IsPlayerExistByEmail(string email);
	}
}
