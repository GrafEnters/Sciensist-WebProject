﻿using EggHuntersSocialNetwork.Data.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace EggHuntersSocialNetwork.Data.Interfaces
{
	public interface IThings
	{
		void CreateThing(Thing user);
		void EditThing(Thing user);

		IEnumerable<Thing> Things { get; }
		bool IsThingExist(string name);
		Thing GetRandom();
		Thing GetThingById(int id);
		Thing GetThingByName(string name);
		
		void DeleteThing(int id);
	}
}
