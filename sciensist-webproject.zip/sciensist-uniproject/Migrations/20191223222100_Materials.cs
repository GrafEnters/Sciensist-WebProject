﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EggHuntersSocialNetwork.Migrations
{
    public partial class Materials : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Things_Materials_materialid",
                table: "Things");

            migrationBuilder.DropIndex(
                name: "IX_Things_materialid",
                table: "Things");

            migrationBuilder.RenameColumn(
                name: "materialid",
                table: "Things",
                newName: "materialId");

            migrationBuilder.AlterColumn<int>(
                name: "materialId",
                table: "Things",
                nullable: false,
                oldClrType: typeof(int),
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "isConducting",
                table: "Materials",
                nullable: false,
                oldClrType: typeof(int));
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "materialId",
                table: "Things",
                newName: "materialid");

            migrationBuilder.AlterColumn<int>(
                name: "materialid",
                table: "Things",
                nullable: true,
                oldClrType: typeof(int));

            migrationBuilder.AlterColumn<int>(
                name: "isConducting",
                table: "Materials",
                nullable: false,
                oldClrType: typeof(bool));

            migrationBuilder.CreateIndex(
                name: "IX_Things_materialid",
                table: "Things",
                column: "materialid");

            migrationBuilder.AddForeignKey(
                name: "FK_Things_Materials_materialid",
                table: "Things",
                column: "materialid",
                principalTable: "Materials",
                principalColumn: "id",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
