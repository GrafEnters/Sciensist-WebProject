﻿using EggHuntersSocialNetwork.Data;
using EggHuntersSocialNetwork.Data.Interfaces;
using EggHuntersSocialNetwork.Data.Models;
using EggHuntersSocialNetwork.Utils;
using EggHuntersSocialNetwork.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using static EggHuntersSocialNetwork.Utils.Question;

namespace EggHuntersSocialNetwork.Controllers
{
	public class GameController : Controller
	{
		private readonly IThings things;
		private readonly IPlayers players;
		private readonly IMaterials materials;
		private static Question question;
		private static string answerMessage;
		private static string findMessage;

		public GameController(IThings things, IMaterials materials, IPlayers players)
		{
			this.things = things;
			this.materials = materials;
			this.players = players;
		}

		public ViewResult Main()
		{
			if (question == null)
				question = QuestionUtil.GenerateQuestion(things, materials);

			var obj = new GameViewModel
			{
				question = question,
				userName = DBObjects.curUser.name,
				answer = ""
			};

			ViewBag.answerMessage = answerMessage;
			ViewBag.findMessage = findMessage;

			return View(obj);
		}

		[HttpPost]
		public RedirectResult Post(GameViewModel model)
		{
			if (model.answer != null)
			{
				string result = Action(model.answer);
				answerMessage = result;

			}
			return Redirect("Main");
		}

		public RedirectResult FindThing(GameViewModel model)
		{
			findMessage = things.GetRandom().name;
			return Redirect("Main");
		}

		private string Action(string action)
		{
			string actionN = string.Join(" ", action.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries)).ToLower();

			switch (actionN.Split(new char[] { ' ' })[0])
			{
				case "ответ":
					return Answer(actionN);
				case "поджечь":
					return Flame(actionN);
				case "разряд":
					return Conduct(actionN);
				case "весы":
					return Balance(actionN);
				case "удар":
					return Hit(actionN);
				case "рассмотреть":
					return Identify(actionN);
				default:
					return "что?";
			}
		}

		private string Answer(string action)
		{

			string answerClean = action.Remove(0, 6).Replace(" ", "");

			if (question.Vtype != VariableType.number)
			{
				if (things.GetThingByName(answerClean) == null)
				{ return "Вещи " + answerClean + " не существуует"; }
			}
			else
			{
				try
				{
					int result = Int32.Parse(answerClean);
					answerClean = result.ToString();
				}
				catch (FormatException)
				{
					return "Надо ответить числом...";
				}
			}

			bool isCorr = question.IsCorrect(answerClean, things, materials);

			string ret;
			if (isCorr)
			{
				DBObjects.curUser.correctAns++;
				ret = "Ответ Правильный!";
			}
			else
			{
				DBObjects.curUser.wrongAns++;
				ret = "Ответ Неправильный!";
			}
			question = QuestionUtil.GenerateQuestion(things, materials);
			if (DBObjects.curUser.name != "Незнакомец")
				players.EditPlayer(DBObjects.curUser);
			return ret;
		}

		private string Balance(string action)
		{
			string answerClean = action.Remove(0, 5);
			string[] objcts = answerClean.Split(" ");
			if (objcts.Length == 4)
			{
				if (things.GetThingByName(objcts[1]) != null)
				{
					if (things.GetThingByName(objcts[3]) != null)
					{
						int left = int.Parse(objcts[0]) * things.GetThingByName(objcts[1]).volume * materials.GetMaterialById(things.GetThingByName(objcts[1]).materialId).density;
						int right = int.Parse(objcts[2]) * things.GetThingByName(objcts[3]).volume * materials.GetMaterialById(things.GetThingByName(objcts[3]).materialId).density;

						if (right > left)
							return "Правая чаша перевешивает";
						else if (left > right)
							return "Левая чаша перевешивает";
						else
							return "Идеальный баланс!";

					}
					else
						return objcts[3] + "? Такой вещи не существует";
				}
				else
					return objcts[1] + "? Такой вещи не существует";
			}
			else
				return "На весах должны быть 2 группы вещей, ни больше, ни меньше";
		}

		private string Hit(string action)
		{
			string answerClean = action.Remove(0, 5);
			string[] objcts = answerClean.Split(" ");
			if (objcts.Length == 2)
			{
				if (things.GetThingByName(objcts[0]) != null)
				{
					if (things.GetThingByName(objcts[1]) != null)
					{
						int first = materials.GetMaterialById(things.GetThingByName(objcts[0]).materialId).durabiliy;
						int secnd = materials.GetMaterialById(things.GetThingByName(objcts[1]).materialId).durabiliy;

						if (first < secnd)
							return objcts[0] + " в твоих руках теперь обломки";
						else if (secnd < first)
							return "После удара от " + objcts[1] + " остались только мельчайшие кусочки";
						else
							return "И " + objcts[0] + " и " + objcts[1] + " теперь просто две кучки пыли";

					}
					else
						return objcts[1] + "? Такой вещи не существует";
				}
				else
					return objcts[0] + "? Такой вещи не существует";
			}
			else
				return "Первым объектом бьёшь второй, не так уж сложно";
		}

		private string Flame(string action)
		{
			string answerClean = action.Remove(0, 8).Replace(" ", "");
			//	answerClean = answerClean.Split(new char[] { ' ' })[0];
			if (things.GetThingByName(answerClean) != null)
			{
				Material material = materials.GetMaterialById(things.GetThingByName(answerClean).materialId);

				if (material.isFlammable)
					return "Сгорело до тла";
				else
					return "Ничего не произошло";

			}
			else
				return answerClean + "? Такой вещи не существует";
		}

		private string Conduct(string action)
		{
			string answerClean = action.Remove(0, 7).Replace(" ", "");
			//	answerClean = answerClean.Split(new char[] { ' ' })[0];
			if (things.GetThingByName(answerClean) != null)
			{
				Material material = materials.GetMaterialById(things.GetThingByName(answerClean).materialId);

				if (material.isConducting)
					return "Лампа на конце цепи мигнула";
				else
					return "Лампа такая же тусклая, как и всегда";

			}
			else
				return answerClean + "? Такой вещи не существует";
		}

		private string Identify(string action)
		{
			string answerClean = action.Remove(0, 12).Replace(" ", "");
			//	answerClean = answerClean.Split(new char[] { ' ' })[0];
			if (things.GetThingByName(answerClean) != null)
			{
				Material material = materials.GetMaterialById(things.GetThingByName(answerClean).materialId);
				return "Очевидно, сделано из " + material.name.ToUpper() +".";

			}
			else
				return answerClean + "? Такой вещи не существует";
		}

	}
}