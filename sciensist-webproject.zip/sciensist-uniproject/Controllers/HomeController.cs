﻿using EggHuntersSocialNetwork.Data;
using EggHuntersSocialNetwork.Data.Models;
using Microsoft.AspNetCore.Mvc;
using HtmlAgilityPack;
using System.Collections.Generic;

namespace EggHuntersSocialNetwork.Controllers
{
    public class HomeController : Controller
    {

        protected ViewModels.NewsViewModel ParseNewsHeaders()
        {
            ViewModels.NewsViewModel resModel = new ViewModels.NewsViewModel();
           
            List<string> headers = new List<string>();
            List<string> imgs = new List<string>();
            List<string> links = new List<string>();


            string url = "https://armorgames.com/";
            var web = new HtmlAgilityPack.HtmlWeb();
            HtmlDocument doc = web.Load(url);

            var newGamesNode = doc.DocumentNode.SelectSingleNode("//section[@class='new-games pull-left']//article//div");
            var gameNodes = newGamesNode.SelectNodes(".//a");
            //var gameNodes = newGamesNode.SelectNodes(".//a[@class='game feature-type-game']");
            if (gameNodes != null)
                foreach (var n in gameNodes)
                {
                    links.Add(n.Attributes["href"].Value);
                    
                    var headerNode = n.SelectSingleNode(".//div[@class='head']");
                    headers.Add(headerNode.InnerText);

                    var imgsNode = n.SelectSingleNode(".//img");
                    imgs.Add(imgsNode.Attributes["src"].Value);

                }
             /*
            var HeaderlNodes = doc.DocumentNode.SelectNodes("//section[@class='new-games']//article//div//a[@class='game feature-type-game']//div[@class='head']");
            if (HeaderlNodes != null)
                foreach (var n in HeaderlNodes)
                {
                    headers.Add(n.InnerText);
                }
              */    

            resModel.Headers = headers.ToArray();
            resModel.links = links.ToArray();
            resModel.imgs = imgs.ToArray();



            return resModel;
        }
        protected List<string> ParseNewsLinks()
        {
            List<string> res = new List<string>();
            string url = "https://armorgames.com/";
            var web = new HtmlAgilityPack.HtmlWeb();
            HtmlDocument doc = web.Load(url);
            var HeaderlNodes = doc.DocumentNode.SelectNodes("//a[@class='game feature-type-game']");
            if (HeaderlNodes != null)
            {
                foreach (var n in HeaderlNodes)
                {
                    res.Add(n.Attributes["href"].Value);
                }
            }


            return res;
        }

        public ViewResult Index()
        {

            //if (question == null)
            //	question = QuestionUtil.GenerateQuestion(things, materials);

            var obj = ParseNewsHeaders();

            return View(obj);
        }






    }
}