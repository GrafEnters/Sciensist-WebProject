﻿using EggHuntersSocialNetwork.Data;
using EggHuntersSocialNetwork.Data.Interfaces;
using EggHuntersSocialNetwork.Data.Models;
using EggHuntersSocialNetwork.ViewModels;
using Microsoft.AspNetCore.Mvc;


namespace EggHuntersSocialNetwork.Controllers
{
	public class AdminController : Controller
	{
		private readonly IPlayers players;

		public AdminController(IPlayers users)
		{
			this.players = users;
		}
		public IActionResult Players()
		{
			var obj = new PlayersViewModel()
			{
				Users = players.Players
			};

			return View(obj);
		}

		[HttpPost]
		public RedirectToActionResult Edit(PlayersViewModel viewModel)
		{

			if (ModelState.IsValid)
			{
				players.EditPlayer(viewModel.editUser);
				
			}
			return RedirectToAction("Players");
		}
	}
}
