﻿using EggHuntersSocialNetwork.Data;
using EggHuntersSocialNetwork.Data.Interfaces;
using EggHuntersSocialNetwork.Data.Models;
using Microsoft.AspNetCore.Mvc;

namespace EggHuntersSocialNetwork.Controllers
{
	public class RegisterController : Controller
	{
		// Тут будут добавлятся и сохраняться элементы в ДБ
		private readonly IPlayers players;

		public RegisterController(IPlayers users)
		{
			this.players = users;
		}

		public IActionResult Register()
		{
			return View();
		}

		[HttpPost]
		public IActionResult Register(Player newUser)
		{
			if (ModelState.IsValid)
			{
				newUser.email = newUser.email.ToLower();
				Player user = players.GetPlayerByEmail(newUser.email);
				if (user != null)
				{
					ViewBag.registerMessage = "Пользователь с такой почтой уже существует";
				}
				else
				{
					players.CreatePlayer(newUser);
					DBObjects.curUser = newUser;
					return Redirect("/Home/Index");
				}
			}
			return View(newUser);
		}
	}
}