﻿using EggHuntersSocialNetwork.Data;
using EggHuntersSocialNetwork.Data.Interfaces;
using EggHuntersSocialNetwork.Data.Models;
using Microsoft.AspNetCore.Mvc;

namespace EggHuntersSocialNetwork.Controllers
{
	public class LoginController : Controller
	{
		// Тут будут добавлятся и сохраняться элементы в ДБ
		private readonly IPlayers players;

		public LoginController(IPlayers users)
		{
			this.players = users;
		}


		public IActionResult Login()
		{
			return View();
		}

		[HttpPost]
		public IActionResult Login(Guest guest)
		{
			if (ModelState.IsValid)
			{
				if (players.IsPlayerExistByEmail(guest.email))
				{
					Player user = players.GetPlayerByEmail(guest.email);
					if (string.Equals(guest.password, user.password))
					{
						DBObjects.curUser = user;
						ViewBag.loginMessage = "Complete";
						return Redirect("/Home/Index");
					}
					else
						ViewBag.loginMessage = "Пароль неправильный";
				}
				else
					ViewBag.loginMessage = "Учётной записи с такой почтой не существует";
			}

			return View(guest);
		}

		public RedirectResult Logout()
		{
			DBObjects.curUser = new Player();
			DBObjects.guestName = "Незнакомец";
			DBObjects.curUser.name = "Незнакомец";

			return Redirect("/Home/Index");
		}

	}
}