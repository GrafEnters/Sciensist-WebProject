﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EggHuntersSocialNetwork.Data;
using EggHuntersSocialNetwork.Data.Interfaces;
using EggHuntersSocialNetwork.Data.Models;
using EggHuntersSocialNetwork.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace EggHuntersSocialNetwork.Controllers
{
	public class ManagerController : Controller
	{
		private readonly IThings things;
		private readonly IMaterials materials;

		public ManagerController(IThings things, IMaterials materials)
		{
			this.things = things;
			this.materials = materials;
		}

		public IActionResult Things()
		{
			var obj = new ThingsViewModel()
			{
				Things = things.Things,
				Materials = materials.Materials,
				toAdd = new Thing(true)
			};

			return View(obj);
		}



		[HttpPost]
		public RedirectToActionResult Change(ThingsViewModel viewModel)
		{
			if (ModelState.IsValid)
				things.EditThing(viewModel.editThing);
			return RedirectToAction("Things");
		}

		[HttpPost]
		public RedirectToActionResult AddNew(ThingsViewModel viewModel)
		{
			if (viewModel.editThing.materialId != -1 && viewModel.editThing.name != null && viewModel.editThing.volume > 0)
				things.CreateThing(viewModel.editThing);
			return RedirectToAction("Things");
		}

		[HttpPost]
		public RedirectToActionResult DeleteThing(ThingsViewModel viewModel)
		{
			things.DeleteThing(viewModel.deleteId);
			return RedirectToAction("Things");
		}



		public IActionResult Materials()
		{
			var obj = new MaterialsViewModel()
			{
				Materials = materials.Materials,
				toAdd = new Material(true)
			};

			return View(obj);
		}




		[HttpPost]
		public RedirectToActionResult ChangeMat(MaterialsViewModel viewModel)
		{
			if (ModelState.IsValid)
				materials.EditMaterial(viewModel.editMaterial);
			return RedirectToAction("Materials");
		}

		[HttpPost]
		public RedirectToActionResult AddNewMat(MaterialsViewModel viewModel)
		{
			if ( viewModel.editMaterial.name != null && viewModel.editMaterial.durabiliy > 0 && viewModel.editMaterial.density > 0)
				materials.CreateMaterial(viewModel.editMaterial);
			return RedirectToAction("Materials");
		}

		[HttpPost]
		public RedirectToActionResult DeleteMat(MaterialsViewModel viewModel)
		{
			materials.DeleteMaterial(viewModel.deleteId);
			return RedirectToAction("Materials");
		}




	}
}